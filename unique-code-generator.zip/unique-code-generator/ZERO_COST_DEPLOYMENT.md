# Zero-Cost Deployment Guide

Every piece of this stack has a genuine $0 tier — no credit card required
anywhere. This guide covers exactly what stays free, the current limits
(verified against Cloudflare's and GitHub's own docs, checked September
2026 — these do change over time, so it's worth a quick re-check if it's
been a while), and the two places *this specific app* could realistically
bump into them.

## The free tier, piece by piece

| Service | Free tier | Card required? |
|---|---|---|
| **GitHub Pages** (frontend) | 1 GB published site, 100 GB bandwidth/month, 10 builds/hour via branch deploys — **no build-count limit at all** if deployed via GitHub Actions (see below) | No |
| **GitHub Actions** (optional deploy method) | Unlimited minutes on **public** repos; 2,000 min/month on private | No |
| **Cloudflare Workers** (API) | 100,000 requests/day, 10 ms CPU time per request, 128 MB memory, 3 MB Worker size, 50 subrequests/request | No |
| **Cloudflare D1** (database) | 5 GB storage, 5,000,000 row-reads/day, 100,000 row-writes/day — bundled into the same free Workers account, no separate signup | No |

One catch worth knowing up front: **GitHub Pages' free tier requires a
public repository.** Private-repo Pages hosting needs GitHub Pro/Team/
Enterprise. If your code needs to stay private, GitHub Pages isn't the
$0 option for the frontend — but Cloudflare Pages (a separate free static
host, unlimited bandwidth) works from a private repo and would slot in
as a drop-in replacement for this project's `frontend/` folder.

For a public repo (the assumption the rest of this guide makes), the
entire chain — hosting, API, database — costs **$0/month**, with no card
on file anywhere.

## Where this specific app could actually hit those limits

Two things worth knowing about, given how `/api/generate` works:

**1. The 10 ms CPU-time cap is the real constraint — not the 100k
requests/day.** Each call to `/api/generate` does one or more D1 batch
round-trips inside a single Worker invocation (see `reserveCodes()` in
`worker/src/index.js`). For the common case — a reasonably large
character set, few collisions — this comfortably fits inside 10 ms. It
gets tighter when:
- the combination space is small relative to what's requested, so the
  worker needs several collision-retry rounds inside one request, or
- a single request asks for close to the frontend's `CHUNK_SIZE` (500
  codes) in one call.

Cloudflare's own guidance puts a typical Worker request at 2–3 ms of CPU
time, so there's real headroom — but a pathological configuration
(short pattern, tiny charset, large quantity) could get cut off
mid-request on the free plan. **Practical mitigation, already partly
built in:** the frontend chunks large requests into 500-code calls
rather than one giant request; if you routinely generate in the
thousands, lowering `CHUNK_SIZE` in `frontend/app.js` (e.g. to 100–200)
trades a few more round-trips for a much safer CPU margin per request.

**2. D1's 100,000 writes/day cap is effectively a cap on total codes
generated per day**, since every reserved code is one write. For
personal use, side projects, or small-team tooling this is enormous
headroom — 100,000 unique codes, every single day, for free, forever.
It only becomes a real constraint if you're issuing codes at genuine
commercial volume (e.g. bulk coupon/license generation for a live
product), at which point Cloudflare's paid tier starts at $5/month with
no daily request cap and 30-second default CPU time — a big jump in
headroom for not much money.

Neither of these means "this won't work for free" — they mean "here's
the specific usage pattern that would eventually outgrow $0."

## Step-by-step, zero-cost path

1. **GitHub account** (free) → create a **public** repository → push this
   project to it.
2. **Enable Pages via GitHub Actions**, not the branch-deploy method:
   *Settings → Pages → Source: GitHub Actions*. The included
   `.github/workflows/deploy-pages.yml` handles the rest. This sidesteps
   the 10-builds/hour soft limit entirely (that cap only applies to
   classic branch-based Pages deploys) and means `frontend/` can stay
   exactly where it is — no need to rename it to `docs/`.
3. **Cloudflare account** (free, no card) → `npx wrangler login`.
4. `npx wrangler d1 create unique-code-generator-db` — the D1 free tier
   applies automatically to the same account; nothing extra to enable.
5. `npx wrangler d1 migrations apply unique-code-generator-db --remote`
6. `npx wrangler deploy` — Workers free tier applies automatically too.
7. Set `frontend/config.js` to the deployed Worker URL, set
   `ALLOWED_ORIGIN` in `worker/wrangler.toml` to your Pages origin,
   redeploy the Worker (`npx wrangler deploy` again).
8. Push — the Actions workflow deploys the frontend automatically from
   here on.

Total cost: **$0/month**, and nothing above requires entering payment
details at any point.

## Keeping an eye on usage (also free)

The Cloudflare dashboard shows live Workers request counts and D1
read/write counts against your daily limits at no cost to view —
worth a glance after the first real burst of usage to confirm you're
nowhere near either ceiling, rather than assuming.
